package com.kingdz.ahellospringcloud.controller;

import java.util.Random;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kingdz.ahelloserviceapi.dto.User;
import com.kingdz.ahelloserviceapi.service.HelloService;

@RestController
public class HelloController implements HelloService {

    private final Logger logger = Logger.getLogger(getClass());

    @Resource
    private DiscoveryClient client;

    @Override
    public String hello() {
        ServiceInstance instance = client.getLocalServiceInstance();

        int sleepTime = new Random().nextInt(3000);
        logger.info("sleepTime:" + sleepTime);
        try {
            Thread.sleep(sleepTime);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        logger.info("/hello,host:" + instance.getHost() + ",service_id:" + instance.getServiceId());
        return "Hello World";
    }

    @Override
    public String hello1(@RequestParam String name) {
        return "Hello " + name;
    }

    @Override
    public User hello2(@RequestHeader String name, @RequestHeader Integer age) {
        return new User(name, age);
    }

    @Override
    public String hello3(@RequestBody User user) {
        return "Hello " + user.getName() + "," + user.getAge();
    }

    @Override
    public String hello4(String name) {
        return "Hello " + name;
    }

    @Override
    public User hello5(String name, Integer age) {
        return new User(name, age);
    }

    @Override
    public String hello6(User user) {
        return "Hello " + user.getName() + "," + user.getAge();
    }

}
