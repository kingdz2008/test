package com.kingdz.ahelloserviceapi.service;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kingdz.ahelloserviceapi.dto.User;

@RequestMapping("/refactor")
public interface HelloService {

    @RequestMapping("hello")
    String hello();

    @RequestMapping("hello1")
    String hello1(@RequestParam("name") String name);

    @RequestMapping("hello2")
    User hello2(@RequestHeader("name") String name, @RequestHeader("age") Integer age);

    @RequestMapping(value = "hello3", method = RequestMethod.POST)
    String hello3(@RequestBody User user);

    @RequestMapping("hello4")
    String hello4(@RequestParam("name") String name);

    @RequestMapping("hello5")
    User hello5(@RequestHeader("name") String name, @RequestHeader("age") Integer age);

    @RequestMapping(value = "hello6", method = RequestMethod.POST)
    String hello6(@RequestBody User user);

}
