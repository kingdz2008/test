package com.kingdz.ahelloserviceapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AHelloServiceApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AHelloServiceApiApplication.class, args);
	}
}
