package com.kingdz.afeignconsumer.service;

import org.springframework.stereotype.Component;

import com.kingdz.ahelloserviceapi.dto.User;
import com.kingdz.ahelloserviceapi.service.HelloService;

@Component
public class HelloServiceFallback implements HelloService {

    @Override
    public String hello() {
        return "error";
    }

    @Override
    public String hello1(String name) {
        return "error";
    }

    @Override
    public User hello2(String name, Integer age) {
        return new User("未知", 0);
    }

    @Override
    public String hello3(User user) {
        return "error";
    }

    @Override
    public String hello4(String name) {
        return "error";
    }

    @Override
    public User hello5(String name, Integer age) {
        return new User("未知", 0);
    }

    @Override
    public String hello6(User user) {
        return "error";
    }

}
