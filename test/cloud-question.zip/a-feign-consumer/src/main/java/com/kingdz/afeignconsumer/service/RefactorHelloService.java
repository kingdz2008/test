package com.kingdz.afeignconsumer.service;

import org.springframework.cloud.netflix.feign.FeignClient;

import com.kingdz.ahelloserviceapi.service.HelloService;

@FeignClient(name = "hello-service", fallback = HelloServiceFallback.class)
public interface RefactorHelloService extends HelloService {

}
