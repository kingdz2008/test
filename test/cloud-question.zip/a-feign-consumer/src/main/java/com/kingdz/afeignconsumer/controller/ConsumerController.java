package com.kingdz.afeignconsumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kingdz.afeignconsumer.service.RefactorHelloService;
import com.kingdz.ahelloserviceapi.dto.User;

@RestController
public class ConsumerController {

    @Autowired
    RefactorHelloService helloService;

    @RequestMapping("/feign-consumer")
    public String helloConsumer() {
        return helloService.hello();
    }

    @RequestMapping("/feign-consumer2")
    public String helloConsumer2() {
        StringBuilder strb = new StringBuilder();
        strb.append(helloService.hello()).append("\n");
        strb.append(helloService.hello1("kingdz")).append("\n");
        strb.append(helloService.hello2("kingdz", 28)).append("\n");
        strb.append(helloService.hello3(new User("kingdz", 28))).append("\n");
        return strb.toString();
    }

    @RequestMapping("/feign-consumer3")
    public String helloConsumer3() {
        StringBuilder strb = new StringBuilder();
        strb.append(helloService.hello()).append("\n");
        strb.append(helloService.hello4("kingdz")).append("\n");
        strb.append(helloService.hello5("kingdz", 28)).append("\n");
        strb.append(helloService.hello6(new User("kingdz", 29))).append("\n");
        return strb.toString();
    }

}
